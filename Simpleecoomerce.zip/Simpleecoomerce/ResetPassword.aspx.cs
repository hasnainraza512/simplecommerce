﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace OnlinePharmacy
{
    public partial class ResetPassword : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["user"] ==null)
            {
                Response.Redirect("ForgetPassword.aspx");
            }
        }

        protected void btnupdate_Click(object sender, EventArgs e)
        {
            using (SqlConnection con=new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("Update Users Set uPass='"+txtpassword.Text+"'",con);
                con.Open();
                cmd.ExecuteNonQuery();
                lblMsg.ForeColor = Color.Green;
                lblMsg.Text = "Password successfully updated";
            }
        }

       
    }
}