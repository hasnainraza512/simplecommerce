﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;

namespace OnlinePharmacy
{
    public partial class ForgetPassword : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnsubmit_Click(object sender, EventArgs e)
        {
            using (SqlConnection con=new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("Select * from Users where uName='"+txtusername.Text+"'",con);
                con.Open();
                SqlDataAdapter sda = new SqlDataAdapter(cmd);
                DataTable dt = new DataTable();
                sda.Fill(dt);
                if (dt.Rows.Count > 0)
                {
                    Session["user"] = txtusername.Text;
                    Response.Redirect("ResetPassword.aspx");
                }
                else
                {
                    lblMsg.ForeColor = Color.Red;
                    lblMsg.Text = "Username not found!";
                }

            }
        }
    }
}