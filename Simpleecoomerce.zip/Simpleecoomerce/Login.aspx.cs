﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace OnlinePharmacy
{
    public partial class Login : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnlogin_Click(object sender, EventArgs e)
        {
            if (AuthenticateUser(txtusername.Text, txtpassword.Text))
            {
                Session["username"] = txtusername.Text;
                Response.Redirect("Home.aspx");
            }
            else
            {
                lblMsg.ForeColor = System.Drawing.Color.Red;
                lblMsg.Text = "Invalid UserName and/or Password";
            }
        }

        private bool AuthenticateUser(string username, string password)
        {
            using (SqlConnection con=new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("spAuthenticateUser",con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter paramuser = new SqlParameter("@uName",txtusername.Text);
                SqlParameter parampass = new SqlParameter("@uPass",txtpassword.Text);

                cmd.Parameters.Add(paramuser);
                cmd.Parameters.Add(parampass);

                con.Open();
                int ReturnCode = (int)cmd.ExecuteScalar();
                return ReturnCode == 1;
            }
        }
    }
}