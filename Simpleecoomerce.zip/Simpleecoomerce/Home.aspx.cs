﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace OnlinePharmacy
{
    public partial class Home : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                using (SqlConnection con=new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select * from Category",con);
                    con.Open();
                    DropDownList1.DataSource = cmd.ExecuteReader();
                    DropDownList1.DataBind();

                    DropDownList1.Items.Insert(0, new ListItem("All Products", "0"));
                }
               
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select * from Products", con);
                    con.Open();
                    dlProducts.DataSource = cmd.ExecuteReader();
                    dlProducts.DataBind();
                }
            }
        }

        protected void dlProducts_ItemCommand(object source, DataListCommandEventArgs e)
        {
            if (e.CommandName== "productdetails")
            {
                Session["producdetails"] = e.CommandArgument.ToString();
                Response.Redirect("ProductDetails.aspx");
            }
        }

        protected void DropDownList1_TextChanged(object sender, EventArgs e)
        {
            if (DropDownList1.SelectedValue=="0")
            {
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select * from Products", con);
                    con.Open();
                    dlProducts.DataSource = cmd.ExecuteReader();
                    dlProducts.DataBind();
                }
            }
            else
            {
                using (SqlConnection con = new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Select * from Products Where idC='" + DropDownList1.SelectedValue + "'", con);
                    con.Open();
                    dlProducts.DataSource = cmd.ExecuteReader();
                    dlProducts.DataBind();
                }
            }
            
        }
    }
}