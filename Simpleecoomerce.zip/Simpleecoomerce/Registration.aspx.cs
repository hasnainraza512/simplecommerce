﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace OnlinePharmacy
{
    public partial class Registration : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnregister_Click(object sender, EventArgs e)
        {
            if (Page.IsValid)
            {
                using (SqlConnection con=new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("spRegisterUser",con);
                    cmd.CommandType = CommandType.StoredProcedure;

                    SqlParameter paramuser = new SqlParameter("@uName", txtusername.Text);
                    SqlParameter password = new SqlParameter("@uPass",txtpassword.Text);

                    cmd.Parameters.Add(paramuser);
                    cmd.Parameters.Add(password);

                    con.Open();
                    int ReturnCode = (int)cmd.ExecuteScalar();
                    if (ReturnCode ==-1)
                    {
                        lblMsg.Text = "Username already in use, please choose another username";
                    }
                    else
                    {
                        Response.Redirect("Login.aspx");
                    }
                }
            }
        }
    }
}