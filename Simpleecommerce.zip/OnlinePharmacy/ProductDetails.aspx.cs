﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;

namespace OnlinePharmacy
{
    public partial class ProductDetails : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["producdetails"]==null)
                {
                    Response.Redirect("Home.aspx");
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        SqlCommand cmd = new SqlCommand("Select * from Products Where idP='"+Session["producdetails"] +"'", con);
                        con.Open();
                        using (SqlDataReader sdr=cmd.ExecuteReader())
                        {
                            sdr.Read();
                            Image1.ImageUrl = sdr["photoPath"].ToString();
                            lbllabel.Text = sdr["labelP"].ToString();
                            lbldescription.Text = sdr["desP"].ToString();
                            lblprice.Text =  sdr["priceP"].ToString();
                            lblqty.Text = sdr["QtyP"].ToString();
                            lblcategory.Text = sdr["idC"].ToString();
                            lblId.Text = sdr["idP"].ToString();
                        }
                    }
                }
               
            }
        }

        protected void btnaddtocart_Click(object sender, EventArgs e)
        {
            if (Session["username"]==null)
            {
                
                Response.Write("<script>alert('Please first login then add to cart')</script>");
            }
            else
            {
                Session["pid"] = lblId.Text;
                int price = Convert.ToInt32(lblprice.Text);
                int qty = Convert.ToInt32(lblqty.Text);
                int totalprice = price * qty;
                using (SqlConnection con=new SqlConnection(CS))
                {
                    SqlCommand cmd = new SqlCommand("Insert into Cart values('"+lbllabel.Text+"','"+lblprice.Text+"','"+lblqty.Text+"','" + Session["pid"] + "','"+Session["username"]+"','"+totalprice+"')",con);
                    con.Open();
                    cmd.ExecuteNonQuery();
                }
                Response.Redirect("shopCart.aspx");
            }
           
        }
    }
}