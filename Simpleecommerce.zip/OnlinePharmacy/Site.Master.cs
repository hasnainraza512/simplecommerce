﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace OnlinePharmacy
{
    public partial class Site : System.Web.UI.MasterPage
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            if (Session["username"]==null)
            {
                lbllogin.Text = "Login";
                lblregistration.Text = "Sign Up";
            }
            else
            {
                LinkButtonlogout.Text = "Log Out";
            }
        }

        protected void LinkButtonmedicines_Click(object sender, EventArgs e)
        {
            Session["medinces"] = "Medicines";
            Response.Redirect("Home.aspx");
               
        }

        protected void LinkButtonlogout_Click(object sender, EventArgs e)
        {
            Session.RemoveAll();
            Response.Redirect("Home.aspx");
        }
    }
}