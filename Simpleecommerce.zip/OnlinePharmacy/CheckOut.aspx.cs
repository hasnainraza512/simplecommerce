﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace OnlinePharmacy
{
    public partial class CheckOut : System.Web.UI.Page
    {
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"]==null)
                {
                    Response.Redirect("Login.aspx");
                   
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        SqlCommand cmd = new SqlCommand("Select * from Users Where uName='" + Session["username"] + "'", con);
                        con.Open();
                        using (SqlDataReader sdr = cmd.ExecuteReader())
                        {
                            sdr.Read();
                            lbluserid.Text = sdr["idU"].ToString();
                        }
                    }
                    txtamount.Text = Session["totalmount"].ToString(); ;
                    TextAreaitems.InnerText = Session["allproducts"].ToString(); ;
                }
            }
        }

        protected void btncheckout_Click(object sender, EventArgs e)
        {
            Response.Write("<form action='https://www.paypal.com/cgi-bin/webscr' method='post' id='buyCredits' name='buyCredits'>");
            Response.Write("<input type='hidden' name='cmd' value='_xclick' />");
            Response.Write("<input type='hidden' name='business' value='Kissmehd@hotmail.com' />");
            Response.Write("<input type='hidden' name='item_name' value='"+TextAreaitems.InnerText+"' />");
            Response.Write(" <input type='hidden' name='amount' value='"+txtamount.Text+"' /> ");
            Response.Write("</form>");

            Response.Write("<script type='text/javascript'>");
            Response.Write("document.getElementById('buyCredits').submit();");
            Response.Write("</script>");
        }
    }
}