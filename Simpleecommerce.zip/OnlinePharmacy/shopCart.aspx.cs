﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Configuration;
using System.Data.SqlClient;
using System.Data;

namespace OnlinePharmacy
{
    public partial class shopCart : System.Web.UI.Page
    {
        private decimal totalamount = (decimal)0.0;
        private string allproducts = "";
        private int productid = 0;
        String CS = ConfigurationManager.ConnectionStrings["DBCS"].ConnectionString;
        protected void Page_Load(object sender, EventArgs e)
        {
            if (!IsPostBack)
            {
                if (Session["username"] == null)
                {
                    Response.Write("<script language='javascript'>window.alert('Please login first then see cart');window.location='Login.aspx';</script>");
                }
                else
                {
                    using (SqlConnection con = new SqlConnection(CS))
                    {
                        SqlCommand cmd = new SqlCommand("Select * from Cart Where Username='"+Session["Username"]+"'", con);
                        con.Open();
                        GridView1.DataSource = cmd.ExecuteReader();
                        GridView1.DataBind();

                    }
                }
            }
          
           
        }

        protected void GridView1_RowDataBound(object sender, GridViewRowEventArgs e)
        {
            if (e.Row.RowType==DataControlRowType.DataRow)
            {
                totalamount += Convert.ToDecimal(DataBinder.Eval(e.Row.DataItem, "TotalPrice"));
                allproducts += Convert.ToString(DataBinder.Eval(e.Row.DataItem, "PName")) + " , ";
                productid += Convert.ToInt32(DataBinder.Eval(e.Row.DataItem, "PId"));

            }
            else if (e.Row.RowType==DataControlRowType.Footer)
            {
                lbltotalprice.Text = totalamount.ToString();
                lblproducts.Text = allproducts;
                lblproductid.Text = productid.ToString();
                e.Row.Cells[3].Text = "Total Amount";
                e.Row.Cells[4].Text = string.Format("{0:c}",totalamount);
            }
        }

      

        protected void Button1_Command(object sender, CommandEventArgs e)
        {
            using (SqlConnection con=new SqlConnection(CS))
            {
                SqlCommand cmd = new SqlCommand("Delete from Cart where CartId='" + e.CommandArgument + "'", con);
                con.Open();
                cmd.ExecuteNonQuery();
                Response.Redirect("shopCart.aspx");
            }
        }

        protected void btncheckout_Click(object sender, EventArgs e)
        {
            Session["totalmount"] = lbltotalprice.Text;
            Session["allproducts"] = lblproducts.Text;
            Session["productids"] = lblproductid.Text;
            Response.Redirect("CheckOut.aspx");
        }
    }
}